package com.jarvis.starter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var statusText: TextView
    private lateinit var transcriptText: TextView
    private lateinit var responseText: TextView
    private lateinit var apiKeyInput: EditText
    private lateinit var speakButton: Button

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    private val requestCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        buildUi()

        tts = TextToSpeech(this, this)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "Speech recognition is not available on this phone."
        } else {
            setupSpeechRecognizer()
        }

        requestNeededPermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(5, 7, 13))
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            setTextColor(Color.rgb(0, 200, 255))
            gravity = Gravity.CENTER
        }

        statusText = TextView(this).apply {
            text = "READY"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }

        apiKeyInput = EditText(this).apply {
            hint = "Paste your OpenAI API key"
            hintTextColor = Color.GRAY
            setTextColor(Color.WHITE)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val saveKeyButton = Button(this).apply {
            text = "SAVE API KEY"
            setOnClickListener {
                saveApiKey()
            }
        }

        speakButton = Button(this).apply {
            text = "🎙 SPEAK TO JARVIS"
            setOnClickListener {
                startListening()
            }
        }

        transcriptText = TextView(this).apply {
            text = "You: —"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 24, 0, 12)
        }

        responseText = TextView(this).apply {
            text = "JARVIS: Ready."
            textSize = 18f
            setTextColor(Color.rgb(0, 200, 255))
            setPadding(0, 8, 0, 24)
        }

        val testButton = Button(this).apply {
            text = "OPEN YOUTUBE"
            setOnClickListener {
                openUrl("https://www.youtube.com")
            }
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(apiKeyInput)
        root.addView(saveKeyButton)
        root.addView(speakButton)
        root.addView(transcriptText)
        root.addView(responseText)
        root.addView(testButton)

        setContentView(root)

        apiKeyInput.setText(getPreferences(MODE_PRIVATE).getString("api_key", ""))
    }

    private fun saveApiKey() {
        val key = apiKeyInput.text.toString().trim()
        if (key.isEmpty()) {
            toast("Enter an API key first.")
            return
        }
        getPreferences(MODE_PRIVATE).edit()
            .putString("api_key", key)
            .apply()
        toast("API key saved on this phone.")
        speak("API key saved.")
    }

    private fun getApiKey(): String {
        return getPreferences(MODE_PRIVATE)
            .getString("api_key", "")
            .orEmpty()
    }

    private fun setupSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "LISTENING..."
            }

            override fun onBeginningOfSpeech() {
                statusText.text = "HEARING YOU..."
            }

            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                statusText.text = "THINKING..."
            }

            override fun onError(error: Int) {
                statusText.text = "READY"
                toast("Speech error: $error")
                speakButton.isEnabled = true
            }

            override fun onResults(results: Bundle?) {
                speakButton.isEnabled = true
                statusText.text = "THINKING..."

                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()

                if (text.isBlank()) {
                    statusText.text = "READY"
                    return
                }

                transcriptText.text = "You: $text"
                handleCommand(text)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO),
                requestCode
            )
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "si-LK")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "si-LK")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        speakButton.isEnabled = false
        speechRecognizer?.startListening(intent)
    }

    private fun handleCommand(command: String) {
        val lower = command.lowercase(Locale.getDefault())

        // Local greeting shortcuts work without an API key or internet access.
        if (lower.contains("hi niroshan") || lower.contains("hey niroshan") ||
            lower.contains("හායි නිරෝශන්") || lower.contains("හායි නිරෝෂන්") ||
            lower.contains("හයි නිරෝශන්") || lower.contains("හෙලෝ නිරෝශන්")) {
            respond("Hi! I'm JARVIS. කොහොමද? මම උදව් කරන්න සූදානම්.")
            return
        }

        if (lower == "hi" || lower == "hello" || lower == "හායි" || lower == "හෙලෝ") {
            respond("Hi! I'm JARVIS. Say ‘Hi Niroshan’ or ask me a question.")
            return
        }

        // A small local tool: opening YouTube does not need cloud AI.
        if ((lower.contains("youtube") || lower.contains("යූටියුබ්")) &&
            (lower.contains("open") || lower.contains("අරින්න"))) {
            openUrl("https://www.youtube.com")
            respond("Opening YouTube.")
            return
        }

        val key = getApiKey()
        if (key.isBlank()) {
            respond("Please save your OpenAI API key first.")
            return
        }

        thread {
            val result = OpenAIClient.sendText(
                apiKey = key,
                userText = command
            )

            runOnUiThread {
                statusText.text = "READY"
                responseText.text = "JARVIS: $result"
                speak(result)
            }
        }
    }

    private fun respond(text: String) {
        statusText.text = "READY"
        responseText.text = "JARVIS: $text"
        speak(text)
    }

    private fun speak(text: String) {
        tts?.speak(
            text,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "JARVIS_RESPONSE"
        )
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            toast("No app can open this link.")
        }
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf<String>()

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECORD_AUDIO)
        }

        if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.READ_CONTACTS)
        }

        if (permissions.isNotEmpty()) {
            requestPermissions(permissions.toTypedArray(), requestCode)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val sinhala = Locale("si", "LK")
            val result = tts?.setLanguage(sinhala)
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
