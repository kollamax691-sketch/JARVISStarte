package com.jarvis.starter

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object OpenAIClient {

    private const val ENDPOINT = "https://api.openai.com/v1/responses"
    private const val MODEL = "gpt-4.1-mini"

    fun sendText(apiKey: String, userText: String): String {
        return try {
            val connection = URL(ENDPOINT).openConnection() as HttpURLConnection

            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = 60_000
            connection.doOutput = true

            connection.setRequestProperty(
                "Authorization",
                "Bearer $apiKey"
            )
            connection.setRequestProperty(
                "Content-Type",
                "application/json"
            )

            val instructions = """
                You are JARVIS, a concise personal Android assistant.
                Understand Sinhala, English and Sinhala-English mixed language.
                For now, answer the user naturally. Do not claim that you
                performed a phone action unless the Android app actually
                performed it.
                Keep simple answers short.
            """.trimIndent()

            val body = JSONObject()
                .put("model", MODEL)
                .put("instructions", instructions)
                .put("input", userText)
                .toString()

            connection.outputStream.use {
                it.write(body.toByteArray(Charsets.UTF_8))
            }

            val responseCode = connection.responseCode

            val stream =
                if (responseCode in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

            val responseText = stream?.bufferedReader()?.use {
                it.readText()
            }.orEmpty()

            if (responseCode !in 200..299) {
                return "API error ($responseCode): $responseText"
            }

            parseOutputText(responseText)

        } catch (e: Exception) {
            "Connection error: ${e.message ?: "unknown error"}"
        }
    }

    private fun parseOutputText(json: String): String {
        val root = JSONObject(json)

        val output = root.optJSONArray("output")
            ?: return "The AI returned no output."

        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue

            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue

                if (part.optString("type") == "output_text") {
                    val text = part.optString("text")
                    if (text.isNotBlank()) return text
                }
            }
        }

        return "I received a response, but could not read its text."
    }
}
