plugins {
    id("com.android.application")
}

android {
    namespace = "com.jarvis.starter"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.jarvis.starter"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1"
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
