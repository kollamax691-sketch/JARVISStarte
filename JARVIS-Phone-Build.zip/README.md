# JARVIS Starter — Android

A starter Android voice assistant supporting Sinhala, English, and mixed Sinhala-English speech.

## Included
- Tap-to-talk speech recognition (uses the phone's installed speech service)
- Local greeting responses for “Hi Niroshan”, “Hey Niroshan”, and Sinhala greeting phrases
- OpenAI Responses API chat for other questions
- Spoken responses with Sinhala TTS where supported, otherwise English fallback
- Local YouTube launch shortcut
- API key entry saved in app-private preferences
- minSdk 26 (Android 8.0) — intended for Android 8.0+ devices, not every device guaranteed

## Build and install
1. Open the project in Android Studio with JDK 17+.
2. Install the Android SDK platform requested by Gradle.
3. Sync the project, then select **Build > Build APK(s)**.
4. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer it to your Android phone and install it. You may need to allow installs from that file manager.
6. Grant microphone permission. For cloud chat, enter an OpenAI API key.

## Important notes
- The greeting shortcuts work without an API key. Voice recognition availability depends on the phone's speech service and language packs.
- Cloud chat needs internet access and an API model available to your OpenAI project. The starter defaults to `gpt-4.1-mini`; change `MODEL` in `OpenAIClient.kt` if needed.
- This prototype stores the API key on-device and sends it directly to the API. Do not distribute it publicly as-is. A released app should call a backend that stores the API key securely.
- “Hi Niroshan” is not an always-listening wake word. The user must open the app and tap **SPEAK TO JARVIS**. Always-on wake-word listening requires a foreground service, battery/privacy design, and additional testing.
- Android restricts silent control of other apps. Calling, SMS, contacts, notifications, and background listening require additional implementation and permissions.
