# Build the JARVIS APK using only an Android phone

This project ZIP contains source code, not an APK. To build without a PC:

1. On your phone, open https://github.com and create/sign in to an account.
2. Create a new repository, for example `JARVISStarter`.
3. Upload the extracted project files and folders to the repository, preserving their paths. Include the `.github/workflows/android-apk.yml` workflow file (GitHub may hide dot-folders in some file pickers).
4. Open the repository's **Actions** tab and select **Build JARVIS APK**. Tap **Run workflow** if it has not started automatically.
5. When the run finishes successfully, open that run, scroll to **Artifacts**, and download `JARVIS-debug-apk`.
6. Extract the downloaded artifact ZIP on your phone and tap the `.apk` file to install. Android may ask you to allow installs from that browser or file manager.

Notes:
- A successful cloud build has not yet been verified; this workflow is provided to attempt it.
- This is a debug APK, not a Play Store release.
- The app's AI features may require configuring an OpenAI API key. Avoid committing API keys to a public repository.
- Minimum Android version is API 26 (Android 8.0) based on the project configuration.
